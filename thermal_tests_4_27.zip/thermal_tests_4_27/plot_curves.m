clear;
load('temperature_data_4_27');

external=temps(:,1);
long_axis=temps(:,2);
short_axis=temps(:,3);
time=transpose(1:length(external));

hold on;
plot(time,external);
plot(time,long_axis);
plot(time,short_axis);

legend('external','internal(long axis)','internal(short axis)');

lb=400;
hb=455;

T_inf = mean(external(400:455));
T_ss = (mean(long_axis(400:455))+mean(short_axis(400:455)))/2;